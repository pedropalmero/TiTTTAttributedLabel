// This is a test harness for your module
// You should do something interesting in this harness 
// to test out the module and to provide instructions 
// to users on how to use it by example.


// open a single window
var win = Ti.UI.createWindow({
	backgroundColor:'white',
	layout: "vertical",
	top: "20dp"
});

var scrollView = Ti.UI.createScrollView({
  contentWidth: 'auto',
  contentHeight: 'auto',
  showVerticalScrollIndicator: true,
  showHorizontalScrollIndicator: true,
  layout: "vertical"
});
win.add(scrollView);

var createSeparator = function() {
   return Ti.UI.createView({
       height: "2dp",
       width: Ti.UI.FILL,
       top: "10dp",
       bottom: "10dp",
       backgroundColor: "orange" 
    });
};

// TODO: write your module tests here
var TiTTTAttributedLabel = require('com.codingpie.titttattributedlabel');
Ti.API.info("module is => " + TiTTTAttributedLabel);

var text = "Examples:\n";
text += "Link: http://www.github.com\n";
text += "Phone: 91-0025125 910025125\n";
text += "Address: 1 Infinite Loop, Cupertino, CA 95014";

var label = TiTTTAttributedLabel.createLabel({
   text: text,
   width: Ti.UI.FILL,
   height: Ti.UI.SIZE,
   color: "#30ad9e",
   textCheckingTypes: TiTTTAttributedLabel.CHECKING_TYPE_LINK|TiTTTAttributedLabel.CHECKING_TYPE_ADDRESS|TiTTTAttributedLabel.CHECKING_TYPE_PHONE_NUMBER
});

scrollView.add(label);
scrollView.add(createSeparator());

// html string
var html = '<html><style type="test/css">body { margin: 0; padding: 0 }</style><body><p><strong>REALMENTE, UN GRAN PA&Iacute;S</strong></p><p>Ubicado en el extremo norte del subcontinente norteamericano, se extiende desde el oc&eacute;ano Atl&aacute;ntico al este, el oc&eacute;ano Pac&iacute;fico al oeste, y hacia el norte hasta el oc&eacute;ano &Aacute;rtico. Comparte frontera con los Estados Unidos al sur, y al noroeste con su estado Alaska. Es el segundo pa&iacute;s m&aacute;s extenso del mundo despu&eacute;s de Rusia, y tambi&eacute;n el m&aacute;s septentrional. Ocupa cerca de la mitad del territorio de Norteam&eacute;rica. Pocos pa&iacute;ses ofrecen semejante variedad de metr&oacute;polis vibrantes, para&iacute;sos a los que escapar entre cadenas monta&ntilde;osas, maravillosos paisajes helados, planicies abiertas y asentamientos remotos.<br />El origen de su nombre es la palabra nativa "kanata" que significa "villa", pero los cart&oacute;grafos europeos del S. XVI la usaron para describir todas las tierras al norte del r&iacute;o San Lorenzo.<br />El animal nacional es el castor. Los deportes nacionales son el lacrosse y el hockey. Los colores nacionales son el rojo y el blanco y el s&iacute;mbolo de su bandera la hoja de Arce.<br />La naci&oacute;n est&aacute; dividida en diez provincias y tres territorios, cada uno con sus propios atributos culturales y geogr&aacute;ficos.<br />Canad&aacute; es una de las naciones m&aacute;s ricas del mundo, con una renta per c&aacute;pita alta, y es miembro de la Organizaci&oacute;n para la Cooperaci&oacute;n y el Desarrollo Econ&oacute;mico (OCDE) y el G8. Los mayores importadores de bienes canadienses son los Estados Unidos, el Reino Unido y Jap&oacute;n.<br /></p><p>&nbsp;</p><p><strong>GASTRONOM&Iacute;A</strong></p><p>En Canad&aacute; la gastronom&iacute;a es variada, muy vistosa y realmente sabrosa. Mezcla la base aborigen con la influencia de las diferentes comunidades de colonos que fueron llegando a estas tierras a lo largo de los siglos. S&oacute;lo en la ciudad de Toronto se mezclan m&aacute;s de 60 comunidades, si bien son la china y la italiana las de mayor presencia en lo que a gastronom&iacute;a se refiere. Adem&aacute;s, siguiendo la tradici&oacute;n francesa, Canad&aacute; ofrece una gran variedad de vinos y licores que acompa&ntilde;an las comidas. Las bebidas hechas a base de savia de Arce son la especialidad de la regi&oacute;n norte, y gustan tambi&eacute;n de la sidra.</p><p>&nbsp;</p><p><strong>CANAD&Aacute; EN DATOS</strong></p><p><strong>Capital:</strong> Ottawa<br /><strong>Idiomas oficiales:</strong> ingl&eacute;s y franc&eacute;s<br /><strong>Forma de gobierno:</strong> Monarqu&iacute;a parlamentaria federal (Monarca: Isabel II)<br /><strong>Lema oficial:</strong> A mari usque ad mare (de mar a mar)<br /><strong>Moneda: </strong>D&oacute;lar canadiense; 1 &euro; = 1,47 $C (media de 2014)<br /><strong>Superficie:</strong> 9 984 670 km&sup2;&nbsp;(2&ordm; Puesto mundial). El 8,62% es agua.<br /><strong>Poblaci&oacute;n:</strong> 35.158.3042 hab. Densidad: 3,41 hab./km&sup2; (Datos de 2013).<br /><strong>PIB:</strong> 1.374.158 M&euro; (est. 2013). Puesto 11 mundial.<br /><strong>Prefijo telef&oacute;nico:</strong> +1<br />Dos de los lagos m&aacute;s grandes del mundo est&aacute;n en Canad&aacute;: Great Bear Lake (el s&eacute;ptimo del mundo y el cuarto de Norteam&eacute;rica) y Great Slave Lake (el d&eacute;cimo del mundo, y el m&aacute;s profundo de Norteam&eacute;rica). Canad&aacute; tiene m&aacute;s lagos que todos los dem&aacute;s pa&iacute;ses del mundo juntos.<br />Las tres ciudades m&aacute;s grandes de Canad&aacute; son Toronto, Montreal y Vancouver. Montreal es la segunda ciudad tras Toronto, y tambi&eacute;n es la segunda ciudad franc&oacute;fona m&aacute;s grande del mundo por detr&aacute;s de Par&iacute;s.<br />La Bah&iacute;a de Fundi, en el Este de Canad&aacute;, tiene las mareas m&aacute;s altas del mundo. Se registran olas de m&aacute;s de 13 metros de altura.<br />El 31% de la superficie de Canad&aacute; est&aacute; cubierta por bosques.<br />Hay 1453 aeropuertos en Canad&aacute;.<br />El 42% de la poblaci&oacute;n canadiense tiene estudios universitarios.<br />Canad&aacute; produce un 1.5% de los alimentos del mundo, pero solo consume un 0.6%.</p></body></html>';
    
var label = TiTTTAttributedLabel.createLabel({
   html: html,
   width: Ti.UI.FILL,
   height: Ti.UI.SIZE,
   color: "#30ad9e",
   verticalAlign: Ti.UI.TEXT_VERTICAL_ALIGNMENT_TOP,
   textCheckingTypes: TiTTTAttributedLabel.CHECKING_TYPE_LINK|TiTTTAttributedLabel.CHECKING_TYPE_ADDRESS|TiTTTAttributedLabel.CHECKING_TYPE_PHONE_NUMBER
});

scrollView.add(label);
scrollView.add(createSeparator());

win.open();

